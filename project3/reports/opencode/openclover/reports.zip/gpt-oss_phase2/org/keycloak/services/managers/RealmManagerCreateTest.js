var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":129,"id":11559,"methods":[{"el":79,"sc":5,"sl":55},{"el":108,"sc":5,"sl":81},{"el":118,"sc":5,"sl":110},{"el":128,"sc":5,"sl":120}],"name":"RealmManagerCreateTest","sl":42}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_224":{"methods":[{"sl":120}],"name":"createRealm_withNameContainingReservedChars_throwsException","pass":true,"statements":[{"sl":122},{"sl":123},{"sl":124},{"sl":125},{"sl":126}]},"test_263":{"methods":[{"sl":110}],"name":"createRealm_withProvidedId_andInvalidId_throwsException","pass":true,"statements":[{"sl":112},{"sl":113},{"sl":114},{"sl":115},{"sl":116}]},"test_78":{"methods":[{"sl":81}],"name":"createRealm_withNullId_generatesIdAndSetsName","pass":true,"statements":[{"sl":83},{"sl":84},{"sl":85},{"sl":86},{"sl":87},{"sl":88},{"sl":89},{"sl":90},{"sl":91},{"sl":92},{"sl":93},{"sl":94},{"sl":96},{"sl":97},{"sl":98},{"sl":99},{"sl":100},{"sl":102},{"sl":103},{"sl":104},{"sl":105},{"sl":106}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [78], [], [78], [78], [78], [78], [78], [78], [78], [78], [78], [78], [78], [78], [], [78], [78], [78], [78], [78], [], [78], [78], [78], [78], [78], [], [], [], [263], [], [263], [263], [263], [263], [263], [], [], [], [224], [], [224], [224], [224], [224], [224], [], [], []]
