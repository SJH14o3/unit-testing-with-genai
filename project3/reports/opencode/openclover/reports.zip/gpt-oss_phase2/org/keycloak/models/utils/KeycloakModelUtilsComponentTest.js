var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":33,"id":9337,"methods":[{"el":17,"sc":5,"sl":13},{"el":32,"sc":5,"sl":19}],"name":"KeycloakModelUtilsComponentTest","sl":11}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_159":{"methods":[{"sl":13}],"name":"testComponentModelGetter_returnsFunction","pass":true,"statements":[{"sl":15},{"sl":16}]},"test_320":{"methods":[{"sl":19}],"name":"testGetComponentModel_null","pass":true,"statements":[{"sl":21},{"sl":22},{"sl":23},{"sl":24},{"sl":25},{"sl":26},{"sl":28},{"sl":30},{"sl":31}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [159], [], [159], [159], [], [], [320], [], [320], [320], [320], [320], [320], [320], [], [320], [], [320], [320], [], []]
