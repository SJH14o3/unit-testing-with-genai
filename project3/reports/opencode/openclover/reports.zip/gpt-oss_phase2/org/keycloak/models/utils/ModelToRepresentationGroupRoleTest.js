var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":74,"id":9755,"methods":[{"el":56,"sc":5,"sl":39},{"el":64,"sc":5,"sl":58},{"el":73,"sc":5,"sl":66}],"name":"ModelToRepresentationGroupRoleTest","sl":22}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_153":{"methods":[{"sl":66}],"name":"testClientRoleMapping","pass":true,"statements":[{"sl":69},{"sl":70},{"sl":71},{"sl":72}]},"test_295":{"methods":[{"sl":58}],"name":"testRealmRoleMapping","pass":true,"statements":[{"sl":61},{"sl":62},{"sl":63}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [295], [], [], [295], [295], [295], [], [], [153], [], [], [153], [153], [153], [153], [], []]
