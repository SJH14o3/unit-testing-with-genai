var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":83,"id":9694,"methods":[{"el":44,"sc":5,"sl":36},{"el":57,"sc":5,"sl":46},{"el":82,"sc":5,"sl":59}],"name":"ModelToRepresentationGroupFullTest","sl":22}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_128":{"methods":[{"sl":59}],"name":"testFullRepresentationRolesAttributes","pass":true,"statements":[{"sl":63},{"sl":64},{"sl":65},{"sl":66},{"sl":67},{"sl":69},{"sl":71},{"sl":73},{"sl":75},{"sl":76},{"sl":77},{"sl":78},{"sl":79},{"sl":80},{"sl":81}]},"test_340":{"methods":[{"sl":46}],"name":"testBriefWhenNotFull","pass":true,"statements":[{"sl":49},{"sl":50},{"sl":51},{"sl":52},{"sl":53},{"sl":54},{"sl":55},{"sl":56}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [340], [], [], [340], [340], [340], [340], [340], [340], [340], [340], [], [], [128], [], [], [], [128], [128], [128], [128], [128], [], [128], [], [128], [], [128], [], [128], [128], [128], [128], [128], [128], [128], [], []]
