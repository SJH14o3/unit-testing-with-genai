var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":122,"id":10533,"methods":[{"el":55,"sc":5,"sl":50},{"el":63,"sc":5,"sl":57},{"el":74,"sc":5,"sl":65},{"el":88,"sc":5,"sl":76},{"el":103,"sc":5,"sl":90},{"el":121,"sc":5,"sl":105}],"name":"OIDCLoginProtocolTest_SessionTest","sl":33}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_115":{"methods":[{"sl":57}],"name":"testReAuthPromptLogin","pass":true,"statements":[{"sl":60},{"sl":62}]},"test_203":{"methods":[{"sl":76}],"name":"testReAuthRequiredAction","pass":true,"statements":[{"sl":79},{"sl":81},{"sl":82},{"sl":83},{"sl":85},{"sl":86},{"sl":87}]},"test_285":{"methods":[{"sl":105}],"name":"testAuthenticationCompletePAR","pass":true,"statements":[{"sl":109},{"sl":111},{"sl":113},{"sl":114},{"sl":116},{"sl":119}]},"test_6":{"methods":[{"sl":90}],"name":"testSendPushSuccess","pass":true,"statements":[{"sl":93},{"sl":94},{"sl":95},{"sl":96},{"sl":97},{"sl":98},{"sl":100},{"sl":101},{"sl":102}]},"test_67":{"methods":[{"sl":65}],"name":"testReAuthAuthTimeExpired","pass":true,"statements":[{"sl":68},{"sl":69},{"sl":71},{"sl":73}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [115], [], [], [115], [], [115], [], [], [67], [], [], [67], [67], [], [67], [], [67], [], [], [203], [], [], [203], [], [203], [203], [203], [], [203], [203], [203], [], [], [6], [], [], [6], [6], [6], [6], [6], [6], [], [6], [6], [6], [], [], [285], [], [], [], [285], [], [285], [], [285], [285], [], [285], [], [], [285], [], [], []]
