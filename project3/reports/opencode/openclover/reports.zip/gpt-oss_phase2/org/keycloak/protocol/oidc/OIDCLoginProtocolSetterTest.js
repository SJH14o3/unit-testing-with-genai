var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":75,"id":10304,"methods":[{"el":38,"sc":5,"sl":35},{"el":46,"sc":5,"sl":40},{"el":53,"sc":5,"sl":48},{"el":60,"sc":5,"sl":55},{"el":67,"sc":5,"sl":62},{"el":74,"sc":5,"sl":69}],"name":"OIDCLoginProtocolSetterTest","sl":25}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_216":{"methods":[{"sl":62}],"name":"testSetHttpHeaders","pass":true,"statements":[{"sl":65},{"sl":66}]},"test_236":{"methods":[{"sl":55}],"name":"testSetUriInfo","pass":true,"statements":[{"sl":58},{"sl":59}]},"test_275":{"methods":[{"sl":48}],"name":"testSetRealm","pass":true,"statements":[{"sl":51},{"sl":52}]},"test_303":{"methods":[{"sl":69}],"name":"testSetEventBuilder","pass":true,"statements":[{"sl":72},{"sl":73}]},"test_318":{"methods":[{"sl":40}],"name":"testSetSession","pass":true,"statements":[{"sl":43},{"sl":44}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [318], [], [], [318], [318], [], [], [], [275], [], [], [275], [275], [], [], [236], [], [], [236], [236], [], [], [216], [], [], [216], [216], [], [], [303], [], [], [303], [303], [], []]
