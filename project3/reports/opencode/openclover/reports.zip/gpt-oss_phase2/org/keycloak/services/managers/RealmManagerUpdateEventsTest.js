var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":80,"id":11794,"methods":[{"el":56,"sc":5,"sl":32},{"el":68,"sc":5,"sl":58},{"el":79,"sc":5,"sl":70}],"name":"RealmManagerUpdateEventsTest","sl":25}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_121":{"methods":[{"sl":32}],"name":"updateRealmEventsConfig_updatesAllProperties","pass":true,"statements":[{"sl":34},{"sl":35},{"sl":36},{"sl":38},{"sl":39},{"sl":40},{"sl":41},{"sl":42},{"sl":43},{"sl":44},{"sl":46},{"sl":47},{"sl":50},{"sl":51},{"sl":52},{"sl":53},{"sl":54},{"sl":55}]},"test_286":{"methods":[{"sl":70}],"name":"updateRealmEventsConfig_unknownListener_throws","pass":true,"statements":[{"sl":72},{"sl":73},{"sl":75},{"sl":76},{"sl":77},{"sl":78}]},"test_64":{"methods":[{"sl":58}],"name":"updateRealmEventsConfig_globalListener_throws","pass":true,"statements":[{"sl":60},{"sl":61},{"sl":63},{"sl":64},{"sl":65},{"sl":66},{"sl":67}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [121], [], [121], [121], [121], [], [121], [121], [121], [121], [121], [121], [121], [], [121], [121], [], [], [121], [121], [121], [121], [121], [121], [], [], [64], [], [64], [64], [], [64], [64], [64], [64], [64], [], [], [286], [], [286], [286], [], [286], [286], [286], [286], [], []]
