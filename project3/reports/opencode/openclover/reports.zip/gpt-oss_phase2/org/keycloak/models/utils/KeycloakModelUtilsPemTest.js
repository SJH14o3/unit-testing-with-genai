var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":44,"id":9510,"methods":[{"el":19,"sc":5,"sl":16},{"el":24,"sc":5,"sl":21},{"el":31,"sc":5,"sl":26},{"el":36,"sc":5,"sl":33},{"el":43,"sc":5,"sl":38}],"name":"KeycloakModelUtilsPemTest","sl":14},{"el":53,"id":9524,"methods":[{"el":52,"sc":5,"sl":48}],"name":"TestUtils","sl":47}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_151":{"methods":[{"sl":33}],"name":"testGetPemFromCertificate_nullReturnsNull","pass":true,"statements":[{"sl":35}]},"test_157":{"methods":[{"sl":21}],"name":"testGetPemFromKey_nullReturnsNull","pass":true,"statements":[{"sl":23}]},"test_163":{"methods":[{"sl":26}],"name":"testGetPemFromKey_validKey","pass":true,"statements":[{"sl":28},{"sl":29},{"sl":30}]},"test_314":{"methods":[{"sl":38},{"sl":48}],"name":"testGetPemFromCertificate_validCertificate","pass":true,"statements":[{"sl":40},{"sl":41},{"sl":42},{"sl":51}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [157], [], [157], [], [], [163], [], [163], [163], [163], [], [], [151], [], [151], [], [], [314], [], [314], [314], [314], [], [], [], [], [], [314], [], [], [314], [], []]
