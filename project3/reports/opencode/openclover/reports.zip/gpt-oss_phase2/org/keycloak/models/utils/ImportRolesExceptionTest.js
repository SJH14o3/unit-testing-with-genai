var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":73,"id":9211,"methods":[{"el":27,"sc":5,"sl":17},{"el":48,"sc":5,"sl":29},{"el":72,"sc":5,"sl":50}],"name":"ImportRolesExceptionTest","sl":15}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_127":{"methods":[{"sl":50}],"name":"importRoles_compositeClientRoleMissing","pass":true,"statements":[{"sl":52},{"sl":54},{"sl":55},{"sl":57},{"sl":59},{"sl":60},{"sl":61},{"sl":62},{"sl":63},{"sl":64},{"sl":66},{"sl":67},{"sl":69},{"sl":71}]},"test_343":{"methods":[{"sl":17}],"name":"importRoles_missingClient","pass":true,"statements":[{"sl":19},{"sl":20},{"sl":21},{"sl":22},{"sl":23},{"sl":24},{"sl":26}]},"test_89":{"methods":[{"sl":29}],"name":"importRoles_compositeRealmRoleMissing","pass":true,"statements":[{"sl":31},{"sl":32},{"sl":33},{"sl":34},{"sl":36},{"sl":37},{"sl":38},{"sl":40},{"sl":42},{"sl":43},{"sl":45},{"sl":47}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [343], [], [343], [343], [343], [343], [343], [343], [], [343], [], [], [89], [], [89], [89], [89], [89], [], [89], [89], [89], [], [89], [], [89], [89], [], [89], [], [89], [], [], [127], [], [127], [], [127], [127], [], [127], [], [127], [127], [127], [127], [127], [127], [], [127], [127], [], [127], [], [127], [], []]
