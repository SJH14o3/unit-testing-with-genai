var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":110,"id":10425,"methods":[{"el":75,"sc":5,"sl":53},{"el":97,"sc":5,"sl":77},{"el":109,"sc":5,"sl":99}],"name":"OIDCLoginProtocolTest_ErrorClientDataTest","sl":32}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_191":{"methods":[{"sl":99}],"name":"testSendErrorCheckerException","pass":true,"statements":[{"sl":102},{"sl":103},{"sl":104},{"sl":106},{"sl":107},{"sl":108}]},"test_276":{"methods":[{"sl":77}],"name":"testSendErrorWithClientData","pass":true,"statements":[{"sl":81},{"sl":82},{"sl":83},{"sl":84},{"sl":88},{"sl":89},{"sl":90},{"sl":91},{"sl":92},{"sl":94},{"sl":95}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [276], [], [], [], [276], [276], [276], [276], [], [], [], [276], [276], [276], [276], [276], [], [276], [276], [], [], [], [191], [], [], [191], [191], [191], [], [191], [191], [191], [], []]
