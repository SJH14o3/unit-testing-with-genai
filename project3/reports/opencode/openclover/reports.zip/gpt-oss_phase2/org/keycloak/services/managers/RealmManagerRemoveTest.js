var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":89,"id":11762,"methods":[{"el":61,"sc":5,"sl":48},{"el":78,"sc":5,"sl":63},{"el":88,"sc":5,"sl":80}],"name":"RealmManagerRemoveTest","sl":35}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_132":{"methods":[{"sl":80}],"name":"removeRealm_notRemoved_noSideEffects","pass":true,"statements":[{"sl":82},{"sl":83},{"sl":84},{"sl":85},{"sl":86},{"sl":87}]},"test_94":{"methods":[{"sl":63}],"name":"removeRealm_successfulRemovesClientsAndPublishesEvent","pass":true,"statements":[{"sl":65},{"sl":66},{"sl":67},{"sl":68},{"sl":69},{"sl":70},{"sl":71},{"sl":73},{"sl":74},{"sl":75},{"sl":76},{"sl":77}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [94], [], [94], [94], [94], [94], [94], [94], [94], [], [94], [94], [94], [94], [94], [], [], [132], [], [132], [132], [132], [132], [132], [132], [], []]
