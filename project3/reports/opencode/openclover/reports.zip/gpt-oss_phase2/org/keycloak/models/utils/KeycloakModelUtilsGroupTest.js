var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":63,"id":9390,"methods":[{"el":18,"sc":5,"sl":14},{"el":24,"sc":5,"sl":20},{"el":30,"sc":5,"sl":26},{"el":37,"sc":5,"sl":32},{"el":57,"sc":5,"sl":39},{"el":62,"sc":5,"sl":59}],"name":"KeycloakModelUtilsGroupTest","sl":12}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_184":{"methods":[{"sl":39}],"name":"testFindGroupByPath_realmValid","pass":true,"statements":[{"sl":41},{"sl":42},{"sl":43},{"sl":44},{"sl":45},{"sl":46},{"sl":47},{"sl":48},{"sl":49},{"sl":50},{"sl":51},{"sl":52},{"sl":53},{"sl":55},{"sl":56}]},"test_185":{"methods":[{"sl":59}],"name":"testFindGroupByPath_returnsNull_onNull","pass":true,"statements":[{"sl":61}]},"test_214":{"methods":[{"sl":14}],"name":"testSplitPath_handlesEscape","pass":true,"statements":[{"sl":16},{"sl":17}]},"test_332":{"methods":[{"sl":20}],"name":"testBuildGroupPath_normal","pass":true,"statements":[{"sl":22},{"sl":23}]},"test_52":{"methods":[{"sl":32}],"name":"testNormalizeGroupPath_variants","pass":true,"statements":[{"sl":34},{"sl":35},{"sl":36}]},"test_76":{"methods":[{"sl":26}],"name":"testBuildGroupPath_escape","pass":true,"statements":[{"sl":28},{"sl":29}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [214], [], [214], [214], [], [], [332], [], [332], [332], [], [], [76], [], [76], [76], [], [], [52], [], [52], [52], [52], [], [], [184], [], [184], [184], [184], [184], [184], [184], [184], [184], [184], [184], [184], [184], [184], [], [184], [184], [], [], [185], [], [185], [], []]
