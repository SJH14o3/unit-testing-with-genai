var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":40,"id":9472,"methods":[{"el":21,"sc":5,"sl":18},{"el":29,"sc":5,"sl":23},{"el":39,"sc":5,"sl":31}],"name":"KeycloakModelUtilsKeyPairTest","sl":16}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_238":{"methods":[{"sl":31}],"name":"testGenerateKeyPairCertificate_withParams","pass":true,"statements":[{"sl":33},{"sl":34},{"sl":35},{"sl":36},{"sl":37},{"sl":38}]},"test_338":{"methods":[{"sl":23}],"name":"testGenerateKeyPairCertificate_default","pass":true,"statements":[{"sl":25},{"sl":26},{"sl":27},{"sl":28}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [338], [], [338], [338], [338], [338], [], [], [238], [], [238], [238], [238], [238], [238], [238], [], []]
