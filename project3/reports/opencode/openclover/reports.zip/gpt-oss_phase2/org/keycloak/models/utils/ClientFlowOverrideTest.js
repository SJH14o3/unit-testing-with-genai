var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":80,"id":9032,"methods":[{"el":31,"sc":5,"sl":26},{"el":43,"sc":5,"sl":33},{"el":64,"sc":5,"sl":45},{"el":79,"sc":5,"sl":66}],"name":"ClientFlowOverrideTest","sl":19}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_198":{"methods":[{"sl":45}],"name":"createClient_withMappedFlow","pass":true,"statements":[{"sl":47},{"sl":48},{"sl":49},{"sl":50},{"sl":51},{"sl":53},{"sl":54},{"sl":56},{"sl":59},{"sl":61},{"sl":63}]},"test_282":{"methods":[{"sl":66}],"name":"updateClient_withFlowMapping","pass":true,"statements":[{"sl":68},{"sl":69},{"sl":70},{"sl":71},{"sl":72},{"sl":74},{"sl":75},{"sl":77},{"sl":78}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [198], [], [198], [198], [198], [198], [198], [], [198], [198], [], [198], [], [], [198], [], [198], [], [198], [], [], [282], [], [282], [282], [282], [282], [282], [], [282], [282], [], [282], [282], [], []]
