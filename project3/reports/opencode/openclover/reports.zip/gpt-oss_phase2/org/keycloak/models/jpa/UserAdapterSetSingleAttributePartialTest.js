var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":77,"id":8934,"methods":[{"el":40,"sc":5,"sl":28},{"el":76,"sc":5,"sl":46}],"name":"UserAdapterSetSingleAttributePartialTest","sl":22}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_1":{"methods":[{"sl":46}],"name":"testSetSingleAttribute_updateExistingAttributes","pass":true,"statements":[{"sl":49},{"sl":50},{"sl":51},{"sl":52},{"sl":53},{"sl":54},{"sl":55},{"sl":56},{"sl":57},{"sl":58},{"sl":61},{"sl":62},{"sl":63},{"sl":65},{"sl":68},{"sl":70},{"sl":71},{"sl":72},{"sl":73},{"sl":75}]},"test_336":{"methods":[{"sl":28}],"name":"testSetSingleAttribute_collectionEqualsBranch","pass":true,"statements":[{"sl":30},{"sl":31},{"sl":32},{"sl":33},{"sl":34},{"sl":36},{"sl":38},{"sl":39}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [336], [], [336], [336], [336], [336], [336], [], [336], [], [336], [336], [], [], [], [], [], [], [1], [], [], [1], [1], [1], [1], [1], [1], [1], [1], [1], [1], [], [], [1], [1], [1], [], [1], [], [], [1], [], [1], [1], [1], [1], [], [1], [], []]
