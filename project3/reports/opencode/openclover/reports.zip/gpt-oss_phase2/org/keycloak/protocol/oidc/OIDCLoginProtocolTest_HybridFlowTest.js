var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":121,"id":10488,"methods":[{"el":98,"sc":5,"sl":51},{"el":103,"sc":5,"sl":100},{"el":120,"sc":5,"sl":105}],"name":"OIDCLoginProtocolTest_HybridFlowTest","sl":31}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_188":{"methods":[{"sl":105}],"name":"testAuthenticatedHybridFlow","pass":true,"statements":[{"sl":108},{"sl":109},{"sl":112},{"sl":114},{"sl":115},{"sl":116},{"sl":117},{"sl":118},{"sl":119}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [188], [], [], [188], [188], [], [], [188], [], [188], [188], [188], [188], [188], [188], [], []]
