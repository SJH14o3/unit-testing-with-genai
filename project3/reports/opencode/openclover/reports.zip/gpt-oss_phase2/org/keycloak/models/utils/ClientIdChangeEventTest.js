var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":68,"id":9068,"methods":[{"el":26,"sc":5,"sl":21},{"el":36,"sc":5,"sl":28},{"el":67,"sc":5,"sl":38}],"name":"ClientIdChangeEventTest","sl":16}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_104":{"methods":[{"sl":38}],"name":"updateClient_clientIdChangePublishesEvent","pass":true,"statements":[{"sl":40},{"sl":41},{"sl":44},{"sl":45},{"sl":48},{"sl":49},{"sl":50},{"sl":51},{"sl":52},{"sl":53},{"sl":54},{"sl":58},{"sl":59},{"sl":66}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [104], [], [104], [104], [], [], [104], [104], [], [], [104], [104], [104], [104], [104], [104], [104], [], [], [], [104], [104], [], [], [], [], [], [], [104], [], []]
