var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":97,"id":11278,"methods":[{"el":74,"sc":5,"sl":64},{"el":85,"sc":5,"sl":76},{"el":96,"sc":5,"sl":88}],"name":"AuthorizationEndpointRegisterTest","sl":44}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_342":{"methods":[{"sl":76}],"name":"testRegisterNotAllowed","pass":true,"statements":[{"sl":79},{"sl":80},{"sl":81},{"sl":82},{"sl":83}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [342], [], [], [342], [342], [342], [342], [342], [], [], [], [], [], [], [], [], [], [], [], [], [], []]
