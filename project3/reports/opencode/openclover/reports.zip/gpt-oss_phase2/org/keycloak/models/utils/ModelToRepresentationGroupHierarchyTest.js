var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":81,"id":9726,"methods":[{"el":53,"sc":5,"sl":35},{"el":64,"sc":5,"sl":55},{"el":73,"sc":5,"sl":66},{"el":80,"sc":5,"sl":75}],"name":"ModelToRepresentationGroupHierarchyTest","sl":21}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_261":{"methods":[{"sl":66}],"name":"testHierarchySubstringSearch","pass":true,"statements":[{"sl":69},{"sl":70},{"sl":71},{"sl":72}]},"test_272":{"methods":[{"sl":75}],"name":"testHierarchyNullSearch","pass":true,"statements":[{"sl":78},{"sl":79}]},"test_54":{"methods":[{"sl":55}],"name":"testHierarchyExactSearch","pass":true,"statements":[{"sl":58},{"sl":59},{"sl":60},{"sl":61},{"sl":62},{"sl":63}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [54], [], [], [54], [54], [54], [54], [54], [54], [], [], [261], [], [], [261], [261], [261], [261], [], [], [272], [], [], [272], [272], [], []]
