var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":79,"id":11030,"methods":[{"el":43,"sc":5,"sl":32},{"el":55,"sc":5,"sl":45},{"el":65,"sc":5,"sl":57},{"el":78,"sc":5,"sl":67}],"name":"TokenManagerStage4Test","sl":20}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_100":{"methods":[{"sl":45}],"name":"validateTokenReuse_newTokenRefreshFlagTrue","pass":true,"statements":[{"sl":47},{"sl":48},{"sl":49},{"sl":51},{"sl":52},{"sl":53},{"sl":54}]},"test_170":{"methods":[{"sl":67}],"name":"validateTokenReuse_reuseLimitExceeded","pass":true,"statements":[{"sl":69},{"sl":70},{"sl":71},{"sl":72},{"sl":73},{"sl":74},{"sl":75},{"sl":77}]},"test_253":{"methods":[{"sl":57}],"name":"validateTokenReuse_newTokenRefreshFlagFalse","pass":true,"statements":[{"sl":59},{"sl":60},{"sl":61},{"sl":63},{"sl":64}]},"test_325":{"methods":[{"sl":32}],"name":"validateTokenReuse_staleToken","pass":true,"statements":[{"sl":35},{"sl":36},{"sl":37},{"sl":38},{"sl":39},{"sl":40},{"sl":42}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [325], [], [], [325], [325], [325], [325], [325], [325], [], [325], [], [], [100], [], [100], [100], [100], [], [100], [100], [100], [100], [], [], [253], [], [253], [253], [253], [], [253], [253], [], [], [170], [], [170], [170], [170], [170], [170], [170], [170], [], [170], [], []]
