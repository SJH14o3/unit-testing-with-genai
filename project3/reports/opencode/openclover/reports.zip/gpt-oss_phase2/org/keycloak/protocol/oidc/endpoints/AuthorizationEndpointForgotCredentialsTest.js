var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":93,"id":11258,"methods":[{"el":73,"sc":5,"sl":63},{"el":81,"sc":5,"sl":75},{"el":92,"sc":5,"sl":84}],"name":"AuthorizationEndpointForgotCredentialsTest","sl":43}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_289":{"methods":[{"sl":75}],"name":"testForgotCredentialsNotAllowed","pass":true,"statements":[{"sl":78},{"sl":79},{"sl":80}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [289], [], [], [289], [289], [289], [], [], [], [], [], [], [], [], [], [], [], [], []]
