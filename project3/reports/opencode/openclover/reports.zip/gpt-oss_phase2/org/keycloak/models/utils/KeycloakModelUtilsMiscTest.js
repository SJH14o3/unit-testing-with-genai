var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":48,"id":9486,"methods":[{"el":16,"sc":5,"sl":12},{"el":21,"sc":5,"sl":18},{"el":26,"sc":5,"sl":23},{"el":47,"sc":5,"sl":28}],"name":"KeycloakModelUtilsMiscTest","sl":10}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_111":{"methods":[{"sl":18}],"name":"testToLowerCaseSafe_null","pass":true,"statements":[{"sl":20}]},"test_277":{"methods":[{"sl":12}],"name":"testGetMasterRealmAdminManagementClientId","pass":true,"statements":[{"sl":14},{"sl":15}]},"test_296":{"methods":[{"sl":28}],"name":"testFindGroupByPath_escapedSlashes","pass":true,"statements":[{"sl":30},{"sl":31},{"sl":32},{"sl":33},{"sl":34},{"sl":35},{"sl":36},{"sl":37},{"sl":38},{"sl":39},{"sl":40},{"sl":41},{"sl":42},{"sl":43},{"sl":45},{"sl":46}]},"test_84":{"methods":[{"sl":23}],"name":"testToLowerCaseSafe_value","pass":true,"statements":[{"sl":25}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [277], [], [277], [277], [], [], [111], [], [111], [], [], [84], [], [84], [], [], [296], [], [296], [296], [296], [296], [296], [296], [296], [296], [296], [296], [296], [296], [296], [296], [], [296], [296], [], []]
