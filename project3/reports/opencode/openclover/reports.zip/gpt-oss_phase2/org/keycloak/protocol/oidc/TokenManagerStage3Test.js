var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":59,"id":11011,"methods":[{"el":32,"sc":5,"sl":29},{"el":41,"sc":5,"sl":34},{"el":50,"sc":5,"sl":43},{"el":58,"sc":5,"sl":52}],"name":"TokenManagerStage3Test","sl":18}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_146":{"methods":[{"sl":43}],"name":"lookupUserFromStatelessToken_byUsername","pass":true,"statements":[{"sl":45},{"sl":46},{"sl":47},{"sl":48},{"sl":49}]},"test_293":{"methods":[{"sl":52}],"name":"lookupUserFromStatelessToken_none","pass":true,"statements":[{"sl":54},{"sl":55},{"sl":56},{"sl":57}]},"test_308":{"methods":[{"sl":34}],"name":"lookupUserFromStatelessToken_bySub","pass":true,"statements":[{"sl":36},{"sl":37},{"sl":38},{"sl":39},{"sl":40}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [308], [], [308], [308], [308], [308], [308], [], [], [146], [], [146], [146], [146], [146], [146], [], [], [293], [], [293], [293], [293], [293], [], []]
