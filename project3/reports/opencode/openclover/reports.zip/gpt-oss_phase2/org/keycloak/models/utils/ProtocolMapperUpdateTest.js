var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":82,"id":10113,"methods":[{"el":42,"sc":5,"sl":20},{"el":65,"sc":5,"sl":44},{"el":81,"sc":5,"sl":67}],"name":"ProtocolMapperUpdateTest","sl":18}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_27":{"methods":[{"sl":67}],"name":"updateClientProtocolMappers_removeOrphanedMapper","pass":true,"statements":[{"sl":69},{"sl":70},{"sl":71},{"sl":72},{"sl":73},{"sl":74},{"sl":76},{"sl":77},{"sl":79},{"sl":80}]},"test_5":{"methods":[{"sl":20}],"name":"updateClientProtocolMappers_addNewMapper","pass":true,"statements":[{"sl":22},{"sl":24},{"sl":26},{"sl":27},{"sl":28},{"sl":29},{"sl":31},{"sl":32},{"sl":33},{"sl":36},{"sl":37},{"sl":39},{"sl":40},{"sl":41}]},"test_98":{"methods":[{"sl":44}],"name":"updateClientProtocolMappers_updateExistingMapper","pass":true,"statements":[{"sl":46},{"sl":47},{"sl":48},{"sl":49},{"sl":50},{"sl":51},{"sl":52},{"sl":54},{"sl":55},{"sl":56},{"sl":57},{"sl":58},{"sl":59},{"sl":60},{"sl":62},{"sl":63},{"sl":64}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [5], [], [5], [], [5], [], [5], [5], [5], [5], [], [5], [5], [5], [], [], [5], [5], [], [5], [5], [5], [], [], [98], [], [98], [98], [98], [98], [98], [98], [98], [], [98], [98], [98], [98], [98], [98], [98], [], [98], [98], [98], [], [], [27], [], [27], [27], [27], [27], [27], [27], [], [27], [27], [], [27], [27], [], []]
