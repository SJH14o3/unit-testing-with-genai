var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":67,"id":9350,"methods":[{"el":21,"sc":5,"sl":13},{"el":39,"sc":5,"sl":23},{"el":65,"sc":5,"sl":41}],"name":"KeycloakModelUtilsContextTest","sl":11}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_180":{"methods":[{"sl":41}],"name":"testCloneContextRealmClientToSession_withClient","pass":true,"statements":[{"sl":43},{"sl":44},{"sl":45},{"sl":46},{"sl":47},{"sl":48},{"sl":49},{"sl":51},{"sl":52},{"sl":53},{"sl":54},{"sl":55},{"sl":56},{"sl":57},{"sl":58},{"sl":59},{"sl":60},{"sl":61},{"sl":63},{"sl":64}]},"test_279":{"methods":[{"sl":23}],"name":"testCloneContextRealmClientToSession_withRealm","pass":true,"statements":[{"sl":25},{"sl":26},{"sl":27},{"sl":28},{"sl":30},{"sl":31},{"sl":32},{"sl":33},{"sl":34},{"sl":35},{"sl":37},{"sl":38}]},"test_42":{"methods":[{"sl":13}],"name":"testCloneContextRealmClientToSession_nullContext","pass":true,"statements":[{"sl":15},{"sl":16},{"sl":17},{"sl":18},{"sl":20}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [42], [], [42], [42], [42], [42], [], [42], [], [], [279], [], [279], [279], [279], [279], [], [279], [279], [279], [279], [279], [279], [], [279], [279], [], [], [180], [], [180], [180], [180], [180], [180], [180], [180], [], [180], [180], [180], [180], [180], [180], [180], [180], [180], [180], [180], [], [180], [180], [], [], []]
