var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":38,"id":9185,"methods":[{"el":37,"sc":5,"sl":18}],"name":"CreateUserTest","sl":17}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_237":{"methods":[{"sl":18}],"name":"createUser_basic","pass":true,"statements":[{"sl":20},{"sl":21},{"sl":22},{"sl":23},{"sl":24},{"sl":26},{"sl":27},{"sl":28},{"sl":30},{"sl":31},{"sl":33},{"sl":34},{"sl":35},{"sl":36}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [237], [], [237], [237], [237], [237], [237], [], [237], [237], [237], [], [237], [237], [], [237], [237], [237], [237], [], []]
