var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":72,"id":9247,"methods":[{"el":38,"sc":5,"sl":16},{"el":54,"sc":5,"sl":40},{"el":71,"sc":5,"sl":56}],"name":"KeycloakModelUtilsAuthFlowTest","sl":14}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_130":{"methods":[{"sl":40}],"name":"testIsFlowUsed_checkBuiltInAndClientOverriding","pass":true,"statements":[{"sl":42},{"sl":43},{"sl":44},{"sl":45},{"sl":46},{"sl":47},{"sl":50},{"sl":51},{"sl":52},{"sl":53}]},"test_291":{"methods":[{"sl":16}],"name":"testDeepFindAuthenticationExecutions_collectsBothFlowsAndExecutions","pass":true,"statements":[{"sl":18},{"sl":19},{"sl":20},{"sl":21},{"sl":22},{"sl":23},{"sl":24},{"sl":25},{"sl":26},{"sl":27},{"sl":28},{"sl":29},{"sl":30},{"sl":31},{"sl":32},{"sl":33},{"sl":34},{"sl":35},{"sl":36},{"sl":37}]},"test_324":{"methods":[{"sl":56}],"name":"testDeepDeleteAuthenticationFlow_removesRecursively","pass":true,"statements":[{"sl":58},{"sl":59},{"sl":60},{"sl":61},{"sl":62},{"sl":63},{"sl":64},{"sl":65},{"sl":66},{"sl":67},{"sl":69}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [291], [], [291], [291], [291], [291], [291], [291], [291], [291], [291], [291], [291], [291], [291], [291], [291], [291], [291], [291], [291], [291], [], [], [130], [], [130], [130], [130], [130], [130], [130], [], [], [130], [130], [130], [130], [], [], [324], [], [324], [324], [324], [324], [324], [324], [324], [324], [324], [324], [], [324], [], [], []]
