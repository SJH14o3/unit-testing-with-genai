var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":115,"id":10321,"methods":[{"el":52,"sc":5,"sl":47},{"el":67,"sc":5,"sl":54},{"el":86,"sc":5,"sl":69},{"el":114,"sc":5,"sl":88}],"name":"OIDCLoginProtocolTest_AdditionalSessionTest","sl":30}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_148":{"methods":[{"sl":88}],"name":"testT3","pass":true,"statements":[{"sl":91},{"sl":92},{"sl":94},{"sl":96},{"sl":99},{"sl":100},{"sl":101},{"sl":103},{"sl":104},{"sl":105},{"sl":106},{"sl":107},{"sl":109},{"sl":110},{"sl":112}]},"test_165":{"methods":[{"sl":69}],"name":"testT2","pass":true,"statements":[{"sl":73},{"sl":75},{"sl":77},{"sl":78},{"sl":80},{"sl":82}]},"test_58":{"methods":[{"sl":54}],"name":"testT1","pass":true,"statements":[{"sl":58},{"sl":59},{"sl":60},{"sl":62},{"sl":63},{"sl":64},{"sl":65},{"sl":66}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [58], [], [], [], [58], [58], [58], [], [58], [58], [58], [58], [58], [], [], [165], [], [], [], [165], [], [165], [], [165], [165], [], [165], [], [165], [], [], [], [], [], [148], [], [], [148], [148], [], [148], [], [148], [], [], [148], [148], [148], [], [148], [148], [148], [148], [148], [], [148], [148], [], [148], [], [], []]
