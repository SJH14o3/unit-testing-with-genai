var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":90,"id":10462,"methods":[{"el":70,"sc":5,"sl":48},{"el":81,"sc":5,"sl":72},{"el":89,"sc":5,"sl":83}],"name":"OIDCLoginProtocolTest_ErrorsTest","sl":29}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_326":{"methods":[{"sl":83}],"name":"testPassiveInteraction","pass":true,"statements":[{"sl":86},{"sl":87},{"sl":88}]},"test_99":{"methods":[{"sl":72}],"name":"testCancelAIAError","pass":true,"statements":[{"sl":75},{"sl":76},{"sl":77},{"sl":78},{"sl":79},{"sl":80}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [99], [], [], [99], [99], [99], [99], [99], [99], [], [], [326], [], [], [326], [326], [326], [], []]
