var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":35,"id":9619,"methods":[{"el":28,"sc":5,"sl":14},{"el":34,"sc":5,"sl":30}],"name":"KeycloakModelUtilsTransactionTest","sl":12}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_174":{"methods":[{"sl":30}],"name":"testGetTransactionLimit_default","pass":true,"statements":[{"sl":32},{"sl":33}]},"test_207":{"methods":[{"sl":14}],"name":"testRunJobInTransaction_wrapsTask","pass":true,"statements":[{"sl":16},{"sl":17},{"sl":18},{"sl":20},{"sl":21},{"sl":23},{"sl":25},{"sl":26},{"sl":27}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [207], [], [207], [207], [207], [], [207], [207], [], [207], [], [207], [207], [207], [], [], [174], [], [174], [174], [], []]
