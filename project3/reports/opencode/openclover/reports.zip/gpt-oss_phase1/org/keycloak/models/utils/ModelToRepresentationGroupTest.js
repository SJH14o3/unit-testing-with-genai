var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":100,"id":9093,"methods":[{"el":46,"sc":5,"sl":36},{"el":56,"sc":5,"sl":48}],"name":"ModelToRepresentationGroupTest","sl":28},{"el":99,"id":9109,"methods":[{"el":81,"sc":9,"sl":61},{"el":98,"sc":9,"sl":83}],"name":"ModelToRepresentationGroupTest.FullGroup","sl":60}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_100":{"methods":[{"sl":61}],"name":"testFullWithRolesAndAttributes","pass":true,"statements":[{"sl":64},{"sl":65},{"sl":66},{"sl":68},{"sl":69},{"sl":70},{"sl":72},{"sl":73},{"sl":75},{"sl":76},{"sl":78},{"sl":79},{"sl":80}]},"test_152":{"methods":[{"sl":83}],"name":"testHierarchyWithSearch","pass":true,"statements":[{"sl":86},{"sl":87},{"sl":88},{"sl":89},{"sl":90},{"sl":92},{"sl":95},{"sl":96},{"sl":97}]},"test_163":{"methods":[{"sl":48}],"name":"testBrief","pass":true,"statements":[{"sl":51},{"sl":52},{"sl":53},{"sl":54},{"sl":55}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [163], [], [], [163], [163], [163], [163], [163], [], [], [], [], [], [100], [], [], [100], [100], [100], [], [100], [100], [100], [], [100], [100], [], [100], [100], [], [100], [100], [100], [], [], [152], [], [], [152], [152], [152], [152], [152], [], [152], [], [], [152], [152], [152], [], [], []]
