var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":82,"id":8069,"methods":[{"el":66,"sc":5,"sl":52},{"el":81,"sc":5,"sl":68}],"name":"JpaUserProviderIdentityConsentTest","sl":30}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_32":{"methods":[{"sl":68}],"name":"testAddConsent_externalClient","pass":true,"statements":[{"sl":70},{"sl":71},{"sl":72},{"sl":73},{"sl":74},{"sl":75},{"sl":76},{"sl":77},{"sl":78},{"sl":79},{"sl":80}]},"test_85":{"methods":[{"sl":52}],"name":"testAddConsent_localClient","pass":true,"statements":[{"sl":54},{"sl":55},{"sl":56},{"sl":57},{"sl":58},{"sl":60},{"sl":61},{"sl":62},{"sl":63},{"sl":64},{"sl":65}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [85], [], [85], [85], [85], [85], [85], [], [85], [85], [85], [85], [85], [85], [], [], [32], [], [32], [32], [32], [32], [32], [32], [32], [32], [32], [32], [32], [], []]
