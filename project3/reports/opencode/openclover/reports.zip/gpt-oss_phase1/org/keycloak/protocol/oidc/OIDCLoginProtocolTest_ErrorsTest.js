var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":90,"id":9520,"methods":[{"el":70,"sc":5,"sl":48},{"el":81,"sc":5,"sl":72},{"el":89,"sc":5,"sl":83}],"name":"OIDCLoginProtocolTest_ErrorsTest","sl":29}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_121":{"methods":[{"sl":72}],"name":"testCancelAIAError","pass":true,"statements":[{"sl":75},{"sl":76},{"sl":77},{"sl":78},{"sl":79},{"sl":80}]},"test_132":{"methods":[{"sl":83}],"name":"testPassiveInteraction","pass":true,"statements":[{"sl":86},{"sl":87},{"sl":88}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [121], [], [], [121], [121], [121], [121], [121], [121], [], [], [132], [], [], [132], [132], [132], [], []]
