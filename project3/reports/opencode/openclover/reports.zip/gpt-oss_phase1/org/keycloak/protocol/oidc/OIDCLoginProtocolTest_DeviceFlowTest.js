var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":93,"id":9461,"methods":[{"el":59,"sc":5,"sl":48},{"el":64,"sc":5,"sl":61},{"el":78,"sc":5,"sl":66},{"el":92,"sc":5,"sl":80}],"name":"OIDCLoginProtocolTest_DeviceFlowTest","sl":28}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_115":{"methods":[{"sl":80}],"name":"testSendErrorDeviceDenial","pass":true,"statements":[{"sl":84},{"sl":86},{"sl":87},{"sl":90},{"sl":91}]},"test_80":{"methods":[{"sl":66}],"name":"testAuthenticatedDeviceApproval","pass":true,"statements":[{"sl":70},{"sl":72},{"sl":73},{"sl":76},{"sl":77}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [80], [], [], [], [80], [], [80], [80], [], [], [80], [80], [], [], [115], [], [], [], [115], [], [115], [115], [], [], [115], [115], [], []]
