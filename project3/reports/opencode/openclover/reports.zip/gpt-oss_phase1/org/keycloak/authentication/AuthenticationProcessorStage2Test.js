var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":96,"id":7834,"methods":[{"el":81,"sc":5,"sl":55}],"name":"AuthenticationProcessorStage2Test","sl":39},{"el":93,"id":7847,"methods":[{"el":92,"sc":9,"sl":86}],"name":"AuthenticationProcessorStage2Test.GenerateCodeTest","sl":85}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_86":{"methods":[{"sl":86}],"name":"testGenerateCode","pass":true,"statements":[{"sl":90},{"sl":91}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [86], [], [], [], [86], [86], [], [], [], [], []]
