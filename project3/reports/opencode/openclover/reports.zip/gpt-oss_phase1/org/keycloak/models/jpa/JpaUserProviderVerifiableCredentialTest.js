var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":103,"id":8270,"methods":[{"el":53,"sc":5,"sl":47},{"el":72,"sc":5,"sl":55},{"el":102,"sc":5,"sl":74}],"name":"JpaUserProviderVerifiableCredentialTest","sl":35}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_48":{"methods":[{"sl":74}],"name":"testAddVerifiableCredential_withoutAttributes","pass":true,"statements":[{"sl":76},{"sl":78},{"sl":79},{"sl":80},{"sl":81},{"sl":83},{"sl":84},{"sl":85},{"sl":86},{"sl":87},{"sl":88},{"sl":89},{"sl":90},{"sl":92},{"sl":93},{"sl":94},{"sl":95},{"sl":96},{"sl":97},{"sl":98},{"sl":99},{"sl":100}]},"test_57":{"methods":[{"sl":55}],"name":"testAddVerifiableCredential_withUserAttributes","pass":true,"statements":[{"sl":57},{"sl":58},{"sl":59},{"sl":60},{"sl":61},{"sl":62},{"sl":63},{"sl":64},{"sl":65},{"sl":66},{"sl":68},{"sl":69},{"sl":70}]},"test_77":{"methods":[{"sl":47}],"name":"testAddVerifiableCredential_missingScope","pass":true,"statements":[{"sl":49},{"sl":50},{"sl":51},{"sl":52}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [77], [], [77], [77], [77], [77], [], [], [57], [], [57], [57], [57], [57], [57], [57], [57], [57], [57], [57], [], [57], [57], [57], [], [], [], [48], [], [48], [], [48], [48], [48], [48], [], [48], [48], [48], [48], [48], [48], [48], [48], [], [48], [48], [48], [48], [48], [48], [48], [48], [48], [], [], [], []]
