var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":140,"id":9417,"methods":[{"el":121,"sc":5,"sl":76},{"el":126,"sc":5,"sl":123},{"el":139,"sc":5,"sl":128}],"name":"OIDCLoginProtocolTest_CodeFlowTest","sl":58}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_64":{"methods":[{"sl":128}],"name":"testAuthenticatedCodeFlow","pass":true,"statements":[{"sl":134},{"sl":135},{"sl":136},{"sl":137},{"sl":138}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [64], [], [], [], [], [], [64], [64], [64], [64], [64], [], []]
