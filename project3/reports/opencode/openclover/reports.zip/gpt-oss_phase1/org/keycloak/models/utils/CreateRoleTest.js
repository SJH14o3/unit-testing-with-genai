var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":51,"id":8712,"methods":[{"el":28,"sc":5,"sl":21},{"el":39,"sc":5,"sl":30},{"el":50,"sc":5,"sl":41}],"name":"CreateRoleTest","sl":16}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_105":{"methods":[{"sl":41}],"name":"createRole_withAttributes","pass":true,"statements":[{"sl":43},{"sl":44},{"sl":45},{"sl":46},{"sl":47},{"sl":48},{"sl":49}]},"test_74":{"methods":[{"sl":30}],"name":"createRole_regular","pass":true,"statements":[{"sl":32},{"sl":33},{"sl":34},{"sl":35},{"sl":36},{"sl":37},{"sl":38}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [74], [], [74], [74], [74], [74], [74], [74], [74], [], [], [105], [], [105], [105], [105], [105], [105], [105], [105], [], []]
