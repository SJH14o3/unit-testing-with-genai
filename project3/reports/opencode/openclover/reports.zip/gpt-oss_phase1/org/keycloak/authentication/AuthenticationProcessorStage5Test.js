var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":109,"id":8017,"methods":[{"el":60,"sc":5,"sl":46},{"el":67,"sc":5,"sl":62},{"el":77,"sc":5,"sl":69},{"el":88,"sc":5,"sl":79},{"el":98,"sc":5,"sl":90},{"el":108,"sc":5,"sl":100}],"name":"AuthenticationProcessorStage5Test","sl":32}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_13":{"methods":[{"sl":100}],"name":"testCreateClientAuthenticatorContext","pass":true,"statements":[{"sl":103},{"sl":104},{"sl":105},{"sl":106},{"sl":107}]},"test_147":{"methods":[{"sl":79}],"name":"testValidateUserServiceAccount","pass":true,"statements":[{"sl":82},{"sl":83},{"sl":84},{"sl":85},{"sl":87}]},"test_155":{"methods":[{"sl":90}],"name":"testCreateAuthenticatorContext","pass":true,"statements":[{"sl":93},{"sl":94},{"sl":95},{"sl":96},{"sl":97}]},"test_180":{"methods":[{"sl":62}],"name":"testValidateUserNull","pass":true,"statements":[{"sl":66}]},"test_47":{"methods":[{"sl":69}],"name":"testValidateUserDisabled","pass":true,"statements":[{"sl":72},{"sl":73},{"sl":74},{"sl":76}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [180], [], [], [], [180], [], [], [47], [], [], [47], [47], [47], [], [47], [], [], [147], [], [], [147], [147], [147], [147], [], [147], [], [], [155], [], [], [155], [155], [155], [155], [155], [], [], [13], [], [], [13], [13], [13], [13], [13], [], []]
