var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":63,"id":8856,"methods":[{"el":18,"sc":5,"sl":14},{"el":24,"sc":5,"sl":20},{"el":30,"sc":5,"sl":26},{"el":37,"sc":5,"sl":32},{"el":57,"sc":5,"sl":39},{"el":62,"sc":5,"sl":59}],"name":"KeycloakModelUtilsGroupTest","sl":12}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_10":{"methods":[{"sl":32}],"name":"testNormalizeGroupPath_variants","pass":true,"statements":[{"sl":34},{"sl":35},{"sl":36}]},"test_169":{"methods":[{"sl":39}],"name":"testFindGroupByPath_realmValid","pass":true,"statements":[{"sl":41},{"sl":42},{"sl":43},{"sl":44},{"sl":45},{"sl":46},{"sl":47},{"sl":48},{"sl":49},{"sl":50},{"sl":51},{"sl":52},{"sl":53},{"sl":55},{"sl":56}]},"test_179":{"methods":[{"sl":26}],"name":"testBuildGroupPath_escape","pass":true,"statements":[{"sl":28},{"sl":29}]},"test_207":{"methods":[{"sl":20}],"name":"testBuildGroupPath_normal","pass":true,"statements":[{"sl":22},{"sl":23}]},"test_209":{"methods":[{"sl":59}],"name":"testFindGroupByPath_returnsNull_onNull","pass":true,"statements":[{"sl":61}]},"test_88":{"methods":[{"sl":14}],"name":"testSplitPath_handlesEscape","pass":true,"statements":[{"sl":16},{"sl":17}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [88], [], [88], [88], [], [], [207], [], [207], [207], [], [], [179], [], [179], [179], [], [], [10], [], [10], [10], [10], [], [], [169], [], [169], [169], [169], [169], [169], [169], [169], [169], [169], [169], [169], [169], [169], [], [169], [169], [], [], [209], [], [209], [], []]
