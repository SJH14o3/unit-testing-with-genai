var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":77,"id":8460,"methods":[{"el":31,"sc":5,"sl":23},{"el":45,"sc":5,"sl":36},{"el":60,"sc":5,"sl":50},{"el":76,"sc":5,"sl":65}],"name":"UserAdapterRequiredActionsTest","sl":18}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_129":{"methods":[{"sl":50}],"name":"testRemoveRequiredAction","pass":true,"statements":[{"sl":52},{"sl":53},{"sl":54},{"sl":55},{"sl":56},{"sl":57},{"sl":58},{"sl":59}]},"test_63":{"methods":[{"sl":23}],"name":"testAddRequiredActionNew","pass":true,"statements":[{"sl":25},{"sl":26},{"sl":27},{"sl":28},{"sl":30}]},"test_75":{"methods":[{"sl":36}],"name":"testAddRequiredActionDuplicate","pass":true,"statements":[{"sl":38},{"sl":39},{"sl":40},{"sl":41},{"sl":42},{"sl":43},{"sl":44}]},"test_79":{"methods":[{"sl":65}],"name":"testGetRequiredActionsStreamDistinct","pass":true,"statements":[{"sl":67},{"sl":68},{"sl":69},{"sl":70},{"sl":71},{"sl":72},{"sl":73},{"sl":74},{"sl":75}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [63], [], [63], [63], [63], [63], [], [63], [], [], [], [], [], [75], [], [75], [75], [75], [75], [75], [75], [75], [], [], [], [], [], [129], [], [129], [129], [129], [129], [129], [129], [129], [129], [], [], [], [], [], [79], [], [79], [79], [79], [79], [79], [79], [79], [79], [79], [], []]
