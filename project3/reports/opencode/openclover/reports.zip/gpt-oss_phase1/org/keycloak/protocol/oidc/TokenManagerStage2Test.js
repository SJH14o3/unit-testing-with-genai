var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":101,"id":9740,"methods":[{"el":45,"sc":5,"sl":38},{"el":50,"sc":5,"sl":47},{"el":63,"sc":5,"sl":58},{"el":68,"sc":5,"sl":65},{"el":74,"sc":5,"sl":70},{"el":83,"sc":5,"sl":76},{"el":90,"sc":5,"sl":85},{"el":100,"sc":5,"sl":92}],"name":"TokenManagerStage2Test","sl":28}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_104":{"methods":[{"sl":92}],"name":"validateUserNotBefore_notBeforeFails","pass":true,"statements":[{"sl":94},{"sl":95},{"sl":96},{"sl":97},{"sl":98}]},"test_112":{"methods":[{"sl":58},{"sl":85}],"name":"validateUserNotBefore_validToken","pass":true,"statements":[{"sl":59},{"sl":60},{"sl":61},{"sl":62},{"sl":87},{"sl":88}]},"test_137":{"methods":[{"sl":65}],"name":"isUserValid_nullUser","pass":true,"statements":[{"sl":67}]},"test_39":{"methods":[{"sl":70}],"name":"isUserValid_disabledUser","pass":true,"statements":[{"sl":72},{"sl":73}]},"test_40":{"methods":[{"sl":58},{"sl":76}],"name":"isUserValid_validUser","pass":true,"statements":[{"sl":59},{"sl":60},{"sl":61},{"sl":62},{"sl":78},{"sl":80},{"sl":81}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [112, 40], [112, 40], [112, 40], [112, 40], [112, 40], [], [], [137], [], [137], [], [], [39], [], [39], [39], [], [], [40], [], [40], [], [40], [40], [], [], [], [112], [], [112], [112], [], [], [], [104], [], [104], [104], [104], [104], [104], [], [], []]
