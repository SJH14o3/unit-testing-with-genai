 

var Packages = {
    nodes: [
                                                                                                        
                
{
    "id": "org.keycloak",
    "text": "org.keycloak",
    "package": "",
    "url": "",
        "icon": "aui-icon aui-icon-small aui-iconfont-devtools-folder-closed",
        "a_attr": {"href": ""},
    "children": [
                                            
                
{
    "id": "org.keycloak.authentication",
    "text": "authentication",
    "package": "org.keycloak.authentication",
    "url": "org/keycloak/authentication/pkg-summary.html",
            "coverage": "74.8%",
        "icon": "aui-icon aui-icon-small aui-iconfont-devtools-folder-closed",
            "li_attr": {"data-is-link": "true"},
        "a_attr": {"href": "org/keycloak/authentication/pkg-summary.html"},
    "children": [
                    ]
},
                                    
                
{
    "id": "org.keycloak.models",
    "text": "models",
    "package": "",
    "url": "",
        "icon": "aui-icon aui-icon-small aui-iconfont-devtools-folder-closed",
        "a_attr": {"href": ""},
    "children": [
                                            
                
{
    "id": "org.keycloak.models.jpa",
    "text": "jpa",
    "package": "org.keycloak.models.jpa",
    "url": "org/keycloak/models/jpa/pkg-summary.html",
            "coverage": "92.4%",
        "icon": "aui-icon aui-icon-small aui-iconfont-devtools-folder-closed",
            "li_attr": {"data-is-link": "true"},
        "a_attr": {"href": "org/keycloak/models/jpa/pkg-summary.html"},
    "children": [
                    ]
},
                                    
                
{
    "id": "org.keycloak.models.utils",
    "text": "utils",
    "package": "org.keycloak.models.utils",
    "url": "org/keycloak/models/utils/pkg-summary.html",
            "coverage": "81.1%",
        "icon": "aui-icon aui-icon-small aui-iconfont-devtools-folder-closed",
            "li_attr": {"data-is-link": "true"},
        "a_attr": {"href": "org/keycloak/models/utils/pkg-summary.html"},
    "children": [
                    ]
},
            ]
},
                                    
                
{
    "id": "org.keycloak.protocol.oidc",
    "text": "protocol.oidc",
    "package": "org.keycloak.protocol.oidc",
    "url": "org/keycloak/protocol/oidc/pkg-summary.html",
            "coverage": "72.8%",
        "icon": "aui-icon aui-icon-small aui-iconfont-devtools-folder-closed",
            "li_attr": {"data-is-link": "true"},
        "a_attr": {"href": "org/keycloak/protocol/oidc/pkg-summary.html"},
    "children": [
                                            
                
{
    "id": "org.keycloak.protocol.oidc.endpoints",
    "text": "endpoints",
    "package": "org.keycloak.protocol.oidc.endpoints",
    "url": "org/keycloak/protocol/oidc/endpoints/pkg-summary.html",
            "coverage": "96.1%",
        "icon": "aui-icon aui-icon-small aui-iconfont-devtools-folder-closed",
            "li_attr": {"data-is-link": "true"},
        "a_attr": {"href": "org/keycloak/protocol/oidc/endpoints/pkg-summary.html"},
    "children": [
                    ]
},
            ]
},
                                    
                
{
    "id": "org.keycloak.services.managers",
    "text": "services.managers",
    "package": "org.keycloak.services.managers",
    "url": "org/keycloak/services/managers/pkg-summary.html",
            "coverage": "70.2%",
        "icon": "aui-icon aui-icon-small aui-iconfont-devtools-folder-closed",
            "li_attr": {"data-is-link": "true"},
        "a_attr": {"href": "org/keycloak/services/managers/pkg-summary.html"},
    "children": [
                    ]
},
            ]
},
            ],
    settings: {
        "icons": {
            "package": {
                "open": "aui-icon aui-icon-small aui-iconfont-devtools-folder-open",
                "closed": "aui-icon aui-icon-small aui-iconfont-devtools-folder-closed"
            },
            "state": {
                "collapsed": "aui-icon aui-icon-small aui-iconfont-collapsed",
                "expanded": "aui-icon aui-icon-small aui-iconfont-expanded",
                "forRemoval": "hidden aui-iconfont-collapsed aui-iconfont-expanded"
            }
        }
    }
};
