var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":87,"id":14740,"methods":[{"el":57,"sc":5,"sl":39},{"el":79,"sc":5,"sl":59},{"el":86,"sc":5,"sl":81}],"name":"RealmManagerCoverageBoost1Test","sl":28}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_355":{"methods":[{"sl":59}],"name":"testSetupBrokerService_Enabled","pass":true,"statements":[{"sl":61},{"sl":62},{"sl":63},{"sl":65},{"sl":66},{"sl":68},{"sl":69},{"sl":70},{"sl":72},{"sl":74},{"sl":76},{"sl":77}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [355], [], [355], [355], [355], [], [355], [355], [], [355], [355], [355], [], [355], [], [355], [], [355], [355], [], [], [], [], [], [], [], [], [], []]
